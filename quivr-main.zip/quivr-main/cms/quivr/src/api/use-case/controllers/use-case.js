'use strict';

/**
 * use-case controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::use-case.use-case');
