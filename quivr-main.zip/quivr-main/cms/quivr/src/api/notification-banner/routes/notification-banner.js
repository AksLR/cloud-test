'use strict';

/**
 * notification-banner router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::notification-banner.notification-banner');
