'use strict';

/**
 * notification-banner service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::notification-banner.notification-banner');
