'use strict';

/**
 * notification-banner controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::notification-banner.notification-banner');
