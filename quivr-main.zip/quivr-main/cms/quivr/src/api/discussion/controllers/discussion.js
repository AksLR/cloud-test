'use strict';

/**
 * discussion controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::discussion.discussion');
