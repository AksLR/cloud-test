'use strict';

/**
 * demo-video controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::demo-video.demo-video');
