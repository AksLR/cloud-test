'use strict';

/**
 * security-question controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::security-question.security-question');
