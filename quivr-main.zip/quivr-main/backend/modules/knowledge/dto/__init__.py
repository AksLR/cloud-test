from .inputs import CreateKnowledgeProperties
from .outputs import DeleteKnowledgeResponse
