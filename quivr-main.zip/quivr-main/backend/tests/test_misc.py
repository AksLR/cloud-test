def test_heatlhz(client):
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_heatlhz_home(client):
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"status": "OK"}
