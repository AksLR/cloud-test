"use client";
import ChatPage from "./[chatId]/page";

export default ChatPage;
