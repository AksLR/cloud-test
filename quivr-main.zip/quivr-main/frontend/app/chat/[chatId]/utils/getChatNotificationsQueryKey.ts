export const getChatNotificationsQueryKey = (chatId: string): string =>
  `notifications-${chatId}`;
