export const chatItemContainerClassName = "flex flex-col gap-3";

export const chatDialogueContainerClassName =
  "flex flex-col flex-1 overflow-y-auto mb-10";
