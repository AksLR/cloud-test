export const linkStyle = {
  white: "text-white hover:text-slate-200",
  black: "text-black",
};
