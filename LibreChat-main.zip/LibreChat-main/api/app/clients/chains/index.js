const runTitleChain = require('./runTitleChain');
const predictNewSummary = require('./predictNewSummary');

module.exports = {
  runTitleChain,
  predictNewSummary,
};
